ABR_RC_car
=============

Use your phone to control a RC car remotely over Bluetooth.

App uses the accelerometer to set pwm commands in order to control the servo and motor of the car.

Good example to see how you can get values from the phone sensors (accelerometer, gyroscope, compass).

For more information, go to:
http://www.socsci.uci.edu/~jkrichma/ABR/index.html

If you have questions, go to:
https://groups.google.com/forum/?hl=en#!forum/android-based-robotics


Requirements
------------

- Android 4.2.2
- IOIO libraries (IOIO0330)


